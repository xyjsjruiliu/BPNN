# ANN
BP神经网络分类器，使用iris数据集，data文件夹里的iris.txt是原始数据，train.txt和test.txt是从原始数据中随机划分的训练集和测试集，用tan-sigmoid做激活函数分类准确率接近100%！原理分析详见[http://blog.csdn.net/zhongkejingwang/article/details/44514073](http://blog.csdn.net/zhongkejingwang/article/details/44514073)
##BP神经网络
![BPNN](https://github.com/jingchenUSTC/ANN/blob/master/pictures/BPNN.png)
##抽象出来的BP网络
![BPNN](https://github.com/jingchenUSTC/ANN/blob/master/pictures/BP.png)
###节点内部示意图：
![Node](https://github.com/jingchenUSTC/ANN/blob/master/pictures/Node.png)
