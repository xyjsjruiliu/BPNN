package com.macb.utils;

public class AI {

	public static int ALL = 0;
	public static int INDOOR = 1;
	public static int OUTDOOR = 2;
	public static String IMAGE_DB_PATH = "./ImgDB/";

}
